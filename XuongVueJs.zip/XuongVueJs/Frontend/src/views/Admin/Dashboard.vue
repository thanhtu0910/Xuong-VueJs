<script setup>
</script>
<template>
    <div class="p-4" style="min-height: 800px;">
       Trang Dashboard
    </div>
</template>
<style scoped lang="css"></style>