<script setup></script>
<template>
   <div class="p-4" style="min-height:800px">Quan li don hang</div>
</template>