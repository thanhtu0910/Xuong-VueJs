<script setup></script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
               <div class="container-fluid">
                  <a class="navbar-brand" href="#">Cao Hong Son - PH49830</a>
               </div>
            </nav>
</template>