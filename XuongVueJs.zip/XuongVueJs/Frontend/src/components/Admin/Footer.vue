<script setup>
</script>
<template>
    <div class="bg-warning ps-4 pt-3 position-absolute end-0 footer">
        <h5 class="text-light">
            @Copyright bootstrap
        </h5>
    </div>
</template>
<style scoped lang="css">
.footer{
    height: 60px;
     width: 100%;
}
</style>